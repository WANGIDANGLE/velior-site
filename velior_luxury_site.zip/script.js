
document.querySelectorAll("button").forEach(btn => {
  btn.addEventListener("click", () => {
    alert("Private release request registered.");
  });
});
